import { initializeApp } from "firebase/app";
import { collection, addDoc, getFirestore, Timestamp, onSnapshot, query, where, or, doc, setDoc, getDocs } from "firebase/firestore";
import { firebaseConfig } from "./env.js"

let curr_open_div = "show-reservations-div"

const app = initializeApp(firebaseConfig)

const db = getFirestore(app)
const res_col_ref = collection(db, "reservations")

let details_row = -1
let details_id = ""
let reservations = []

const details_jp = {
  guest_name: "名前",
  guest_room: "部屋番号",
  guest_phone: "連絡先",
  timestamp_date: "乗車日時",
  destination: "目的地",
  car_type: "指定",
  car_number: "台数",
  people_number: "人数",
  bags: "荷物",
  estimate: "見積り",
  remarks: "備考",
  company: "タクシー会社",
  company_phone: "先方電話番号",
  tanto: "自社担当者",
  senpo: "先方担当者",
}

window.onload = () => {
  getReservations()
  node("new-reservation-confirm").onclick = confirmReservation
  node("new-reservation-button").onclick = () => {
    toggleWindow("new-reservation-div", "block")
    resetForm() 
  }    
  node("show-reservations-button").onclick = () => {
    toggleWindow("show-reservations-div", "block")
    getReservations()
  }
  node("new-reservaion-reset").onclick = resetForm
  node("history-button").onclick = () => {
    toggleWindow("show-history-div", "block")
    getAllReservations()
  }
  node("print-today").onclick = () => {
    toggleWindow("show-today-div", "block")
    getTodayReservations()
  }
};

function confirmReservation() {
  const guest_name = node("input-name").value
  if (guest_name == "") {
    fireError("お客様のお名前を記入してください")
    return
  }

  const guest_room = node("input-room").value
  const guest_phone = node("input-phone").value
  if (guest_room == "" && guest_phone == "") {
    fireError("お部屋番号かご連絡先を記入してください")
    return
  }

  const reservation_date = node("input-day").value
  if (reservation_date == "") {
    fireError("ご乗車日を選択してください")
    return
  }
  const timestamp_date = getTimestamp(reservation_date)

  let today = new Date();
  const dd = String(today.getDate()).padStart(2, '0');
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const yyyy = today.getFullYear();
  today = yyyy + "年" + mm + "月" + dd + "日";
  
  const destination = node("input-destination").value
  if (destination == "") {
    fireError("降車住所を記入してください")
    return
  }

  const car_type = node("input-type").value
  const car_number = node("input-number").value
  const people_number = node("input-people").value
  const bags = node("input-bags").value
  const estimate = node("input-estimate").value
  const remarks = node("input-remarks").value
  
  const company = node("input-company").value
  const company_phone = node("input-company-phone").value
  const tanto = node("input-tanto").value
  const senpo = node("input-senpo").value

  const data = {
    guest_name: guest_name,
    guest_room: guest_room,
    guest_phone: guest_phone,
    timestamp_date: timestamp_date,
    destination: destination,
    car_type: car_type,
    car_number: car_number,
    people_number: people_number,
    bags: bags,
    estimate: estimate,
    remarks: remarks,
    company: company,
    company_phone: company_phone,
    tanto: tanto,
    senpo: senpo,
    today: today,
    changes: {},
    stat: "active"
  }

  addDoc(res_col_ref, data)
    .then((docRef) => {
      console.log("Reservation added successfully!", docRef.id)
      toggleWindow("show-reservations-div", "block")
      showDetails(docRef.id, "show-table")
      node("print-button").click()
    })
}

function fireError(error_string) {
  node("error-window-div").style.display = "flex"
  node("error-window-div").style.top = window.scrollY + window.innerHeight*.2
  node("error-message").innerHTML = error_string
  setTimeout(clearError, 5000)
}

function clearError() {
  node("error-window-div").style.display = "none"
}

function getTimestamp(date_string) {
  return Timestamp.fromDate(new Date(date_string))
}

function getDate(date_timestamp) {
  return date_timestamp.toDate()
}

function toggleWindow(divId, mode) {
  if (curr_open_div != "") {
    node(curr_open_div).style.display = "none"
  }
  node(divId).style.display = mode
  curr_open_div = divId
}

function getAllReservations() {
  let q = query(res_col_ref, or(where("timestamp_date", "<=", Timestamp.now()), where("stat", "==", "cancel")))
  onSnapshot(q, querySnapshot => {
    writeHistoryTable(querySnapshot)
  })
}

function getReservations() {
  let q = query(res_col_ref, where("timestamp_date", ">=", Timestamp.now()), where("stat", "==", "active"))
  onSnapshot(q, querySnapshot => {
    writeTable(querySnapshot)
  })
}

function getTodayReservations() {
  const today = new Date()
  const tomorrow = new Date(today)
  tomorrow.setDate(today.getDate() + 1)
  today.setHours(0, 0, 0, 0)
  tomorrow.setHours(0, 0, 0, 0)
  let q = query(res_col_ref, where("timestamp_date", ">", Timestamp.fromDate(today)), where("timestamp_date", "<", Timestamp.fromDate(tomorrow)))
  getDocs(q).then(querySnapshot => {
    todayTable(querySnapshot)
  })
}

function todayTable(snapshot) {
  details_id = ""
  details_row = -1
  node("show-changes-content").innerHTML = ""
  node("show-changes-div").style.display = "none"
  reservations = []
  snapshot.forEach(doc => {
    reservations.push({...doc.data(), id: doc.id, ref: doc.ref})
  })
  reservations.sort((a, b) => sortBy(a, b, "timestamp_date"))

  const table = node("show-today-table")
  table.innerHTML = "<tr><th id='table-date'>乗車時</th><th>名前</th><th id='table-dest'>降車住所</th><th class='table-small'>台数</th><th class='table-small'>人数</th><th id='table-comp'>タクシー会社</th></tr>"
  reservations.forEach(reservation => {
    let tr = document.createElement("tr")
    tr.className += "show-table-row"

    let td_datetime = document.createElement("td")
    let date1 = getDate(reservation.timestamp_date).toLocaleString("jp-JA", { hour12: false })
    let date3 = date1.replace(",", "")
    let date2 = date3.split(" ")
    let datel = date2[0].split("/")
    let dater = date2[1].split(":")
    td_datetime.innerHTML = dater[0] + ":" + dater[1]
    tr.appendChild(td_datetime)

    node("today-title").innerHTML = datel[1] + "月" + datel[2] + "日　タクシー予約一覧"

    let td_name = document.createElement("td")
    td_name.innerHTML = reservation.guest_name + "様"
    tr.appendChild(td_name)

    let td_destination = document.createElement("td")
    td_destination.innerHTML = reservation.destination
    tr.appendChild(td_destination)

    let td_carnum = document.createElement("td")
    td_carnum.innerHTML = reservation.car_number
    tr.appendChild(td_carnum)

    let td_people = document.createElement("td")
    td_people.innerHTML = reservation.people_number
    tr.appendChild(td_people)

    let td_company = document.createElement("td")
    td_company.innerHTML = reservation.company
    tr.appendChild(td_company)

    table.appendChild(tr)
  })
  const printDiv = document.getElementById("show-today-div").innerHTML
  document.body.innerHTML = printDiv
  window.print()
  window.open("index.html", "_self")
}

function writeTable(snapshot) {
  details_id = ""
  details_row = -1
  node("show-changes-content").innerHTML = ""
  node("show-changes-div").style.display = "none"
  reservations = []
  snapshot.forEach(doc => {
    reservations.push({...doc.data(), id: doc.id, ref: doc.ref})
  })
  reservations.sort((a, b) => sortBy(a, b, "timestamp_date"))

  const table = node("show-table")
  table.innerHTML = "<tr><th id='table-date'>乗車日時</th><th>名前</th><th id='table-dest'>降車住所</th><th class='table-small'>台数</th><th class='table-small'>人数</th><th id='table-comp'>タクシー会社</th></tr>"
  reservations.forEach(reservation => {
    let tr = document.createElement("tr")
    tr.id = reservation.id
    tr.className += "show-table-row"
    tr.onclick = () => showDetails(reservation.id, "show-table")

    let td_datetime = document.createElement("td")
    let date1 = getDate(reservation.timestamp_date).toLocaleString("jp-JA", { hour12: false })
    let date3 = date1.replace(",", "")
    let date2 = date3.split(" ")
    let datel = date2[0].split("/")
    let dater = date2[1].split(":")
    td_datetime.innerHTML = datel[0] + "年" + datel[1] + "月" + datel[2] + "日　" + dater[0] + ":" + dater[1]
    tr.appendChild(td_datetime)

    let today = new Date();
    const dd = String(today.getDate());
    const mm = String(today.getMonth() + 1);
    const yyyy = today.getFullYear();
    today = yyyy + "年" + mm + "月" + dd + "日";
    if (today == datel[0] + "年" + datel[1] + "月" + datel[2] + "日") {
      tr.className += " today-departure"
    }

    let td_name = document.createElement("td")
    td_name.innerHTML = reservation.guest_name + "様"
    tr.appendChild(td_name)

    let td_destination = document.createElement("td")
    td_destination.innerHTML = reservation.destination
    tr.appendChild(td_destination)

    let td_carnum = document.createElement("td")
    td_carnum.innerHTML = reservation.car_number
    tr.appendChild(td_carnum)

    let td_people = document.createElement("td")
    td_people.innerHTML = reservation.people_number
    tr.appendChild(td_people)

    let td_company = document.createElement("td")
    td_company.innerHTML = reservation.company
    tr.appendChild(td_company)

    table.appendChild(tr)
  })
}

function sortBy(a, b, constraint) {
  let fa = a[constraint], fb = b[constraint]
  if (fa < fb) return -1
  if (fa > fb) return 1
  return 0
}

function showDetails(reservation_id, table_name) {
  const table = node(table_name)
  node("print-button").style.display = table_name=="show-table"?"block":"none"
  node("cancel-button").style.display = table_name=="show-table"?"block":"none"
  

  if (details_row != -1) {
    table.deleteRow(details_row)
    if (reservation_id == details_id) {
      details_id = ""
      details_row = -1
      node("show-changes-div").style.display = "none"
      node("show-changes-button").style.display = "none"
      return
    }
  }
  details_id = reservation_id
  const row = node(reservation_id)
  const new_row = table.insertRow(row.rowIndex+1)
  details_row = new_row.rowIndex
  const cell = new_row.insertCell(0)
  cell.colSpan = 6
  cell.innerHTML = node("details-div").innerHTML
  cell.className = "details"

  let reservation = reservations.find(o => o.id == details_id)
  node("revert-button").style.display = reservation.stat=="cancel"?"block":"none"

  if (table_name == "show-table") {
    node("details-name").onclick = () => change(reservation_id, "名前", reservation.guest_name, "guest_name")
    node("details-room").onclick = () => change(reservation_id, "部屋番号", reservation.guest_room, "guest_room")
    node("details-phone").onclick = () => change(reservation_id, "連絡先", reservation.guest_phone, "guest_phone")
    node("details-dest").onclick = () => change(reservation_id, "降車場所住所", reservation.destination, "destination")
    node("details-type").onclick = () => change(reservation_id, "車種・会社指定", reservation.car_type, "car_type")
    node("details-cars").onclick = () => change(reservation_id, "台数", reservation.car_number, "car_number")
    node("details-people").onclick = () => change(reservation_id, "人数", reservation.people_number, "people_number")
    node("details-bags").onclick = () => change(reservation_id, "荷物", reservation.bags, "bags")
    node("details-estimate").onclick = () => change(reservation_id, "お見積り", reservation.estimate, "estimate")
    node("details-remarks").onclick = () => change(reservation_id, "備考", reservation.remarks, "remarks")
    node("details-comp").onclick = () => change(reservation_id, "タクシー会社", reservation.company, "company")
    node("details-senpo").onclick = () => change(reservation_id, "先方担当者", reservation.senpo, "senpo")
    node("details-compphone").onclick = () => change(reservation_id, "先方電話番号", reservation.company_phone, "company_phone")
    node("details-tanto").onclick = () => change(reservation_id, "自社担当者", reservation.tanto, "tanto")
  } else {
    node("details-name").onclick = null
    node("details-room").onclick = null
    node("details-phone").onclick = null
    node("details-dest").onclick = null
    node("details-type").onclick = null
    node("details-cars").onclick = null
    node("details-people").onclick = null
    node("details-bags").onclick = null
    node("details-estimate").onclick = null
    node("details-remarks").onclick = null
    node("details-comp").onclick = null
    node("details-senpo").onclick = null
    node("details-compphone").onclick = null
    node("details-tanto").onclick = null
  }
  
  let date1 = getDate(reservation.timestamp_date).toLocaleString("jp-JA", { hour12: false })
  let date3 = date1.replace(",", "")
  let date2 = date3.split(" ")
  let datel = date2[0].split("/")
  let dater = date2[1].split(":")
  node("details-time").onclick = () => change(reservation_id, "乗車日時", datel[0] + "年" + datel[1] + "月" + datel[2] + "日　" + dater[0] + ":" + dater[1], "timestamp_date")
  node("details-name").innerHTML = reservation.guest_name
  node("details-room").innerHTML = reservation.guest_room==""?"　":reservation.guest_room
  node("details-phone").innerHTML = reservation.guest_phone==""?"　":reservation.guest_phone
  node("details-time").innerHTML = datel[0] + "年" + datel[1] + "月" + datel[2] + "日　" + dater[0] + ":" + dater[1]
  node("details-dest").innerHTML = reservation.destination
  node("details-type").innerHTML = reservation.car_type==""?"　":reservation.car_type
  node("details-cars").innerHTML = reservation.car_number==""?"　":reservation.car_number
  node("details-people").innerHTML = reservation.people_number==""?"　":reservation.people_number
  node("details-bags").innerHTML = reservation.bags==""?"　":reservation.bags
  node("details-estimate").innerHTML = reservation.estimate==""?"　":reservation.estimate
  node("details-remarks").innerHTML = reservation.remarks==""?"　":reservation.remarks
  node("details-uketsuke").innerHTML = reservation.today
  node("details-comp").innerHTML = reservation.company==""?"　":reservation.company
  node("details-senpo").innerHTML = reservation.senpo==""?"　":reservation.senpo
  node("details-compphone").innerHTML = reservation.company_phone==""?"　":reservation.company_phone
  node("details-tanto").innerHTML = reservation.tanto==""?"　":reservation.tanto
  node("print-button").onclick = () => {window.open("print.html?name="+reservation.guest_name+"&room="+reservation.guest_room+"&phone="+reservation.guest_phone
      +"&time="+datel[0] + "年" + datel[1] + "月" + datel[2] + "日　" + dater[0] + ":" + dater[1]+"&dest="+reservation.destination
      +"&type="+reservation.car_type+"&cars="+reservation.car_number+"&people="+reservation.people_number+"&bags="+reservation.bags
      +"&estimate="+reservation.estimate+"&remarks="+reservation.remarks+"&comp="+reservation.company+"&senpo="+reservation.senpo
      +"&compphone="+reservation.company_phone+"&tanto="+reservation.tanto+"&today="+reservation.today)}
  node("cancel-button").onclick = () => {
    node("cancel-div").style.display = "block"
    node("cancel-cancel").onclick = () => {
      node("cancel-div").style.display = "none"
      node("cancel-tanto").value = ""
    }
    node("confirm-cancel").onclick = () => {
      if (node("cancel-tanto").value == "") return
      const tanto = node("cancel-tanto").value
      setDoc(reservation.ref, {
        stat: "cancel",
        cancel_tanto: tanto
      }, {merge: "true"})
      node("cancel-div").style.display = "none"
      node("cancel-tanto").value = ""
    }
  }
  if (Object.keys(reservation.changes).length != 0) {
    node("show-changes-button").style.display = "block"
    node("show-changes-button").onclick = () => {
      node("show-changes-content").innerHTML = ""
      node("show-changes-div").style.display = "block"
      node("show-changes-div").onclick = () => node("show-changes-div").style.display = "none"
      let h = document.createElement("h4")
      h.innerHTML = "変更履歴"
      document.getElementById("show-changes-content").appendChild(h)
      Object.keys(reservation.changes).forEach((key) => {
        let change = reservation.changes[key]
        let p = document.createElement("p")
        let after = change.after
        if (change.item == "timestamp_date") {
          let date1 = getDate(reservation.timestamp_date).toLocaleString("jp-JA", { hour12: false })
          let date3 = date1.replace(",", "")
          let date2 = date3.split(" ")
          let datel = date2[0].split("/")
          let dater = date2[1].split(":")
          after = datel[0] + "年" + datel[1] + "月" + datel[2] + "日　" + dater[0] + ":" + dater[1]
        }
        p.innerHTML = details_jp[change.item] + "：　" + change.before + "　→　" + after + "　|　<span style='font-weight:bold;'>" + change.tanto + "</span>"
        document.getElementById("show-changes-content").appendChild(p)
      })
    }
  }
  node("revert-button").onclick = () => {
    setDoc(reservation.ref, {
      stat: "active",
      cancel_tanto: ""
    }, {merge: "true"})
  }
}

function node(id) {
  return document.getElementById(id)
}

function resetForm() {
  node("input-name").value = ""
  node("input-room").value = ""
  node("input-phone").value = ""
  node("input-day").value = ""
  node("input-destination").value = ""
  node("input-number").value = ""
  node("input-people").value = ""
  node("input-bags").value = ""
  node("input-type").value = ""
  node("input-estimate").value = ""
  node("input-remarks").value = ""
  node("input-company").value = ""
  node("input-company-phone").value = ""
  node("input-senpo").value = ""
  node("input-tanto").value = ""
}

function change(id, title, before, field) {
  node("change-div").style.top = window.scrollY + window.innerHeight*.5
  node("change-div").style.display = "flex"
  node("change-title").innerHTML = title + "変更"
  node("change-before").innerHTML = before
  if (field == "timestamp_date") {
    node("change-after").type = "datetime-local"
  } else {
    node("change-after").type = "text"
  }
  node("change-cancel").onclick = () => {
    node("change-div").style.display = "none"
    node("change-after").value = ""
    node("change-tanto").value = ""
  }
  node("change-confirm").onclick = () => {
    const tanto = node("change-tanto").value
    if (tanto == "") {
      return
    }
    let after = node("change-after").value
    if (field == "timestamp_date") {
      after = getTimestamp(after)
    }
    const docRef = doc(db, "reservations", id)
    const t = Timestamp.now().seconds
    setDoc(docRef, {
      [field]: after==""?"　":after,
      changes: {
        [t]: {
          item: field,
          before: before,
          after: after,
          tanto: tanto
        }
      }
    }, { merge: true }).then(() => {
      node("change-div").style.display = "none"
      node("change-after").value = ""
      node("change-tanto").value = ""
      showDetails(id, "show-table")
    })
  }
}

function writeHistoryTable(snapshot) {
  reservations = []
  snapshot.forEach(doc => {
    reservations.push({...doc.data(), id: doc.id, ref: doc.ref})
  })
  reservations.sort((a, b) => sortBy(b, a, "timestamp_date"))

  const table = node("show-history-table")
  table.innerHTML = "<tr><th id='table-date'>乗車日時</th><th>名前</th><th id='table-dest'>降車住所</th><th class='table-small'>台数</th><th class='table-small'>人数</th><th id='table-comp'>タクシー会社</th></tr>"
  reservations.forEach(reservation => {
    let tr = document.createElement("tr")
    tr.id = reservation.id
    tr.className += "show-table-row"
    tr.className += reservation.stat == "cancel"?" cancel-row":""
    tr.onclick = () => showDetails(reservation.id, "show-history-table")

    let td_datetime = document.createElement("td")
    let date1 = getDate(reservation.timestamp_date).toLocaleString("jp-JA", { hour12: false })
    let date3 = date1.replace(",", "")
    let date2 = date3.split(" ")
    let datel = date2[0].split("/")
    let dater = date2[1].split(":")
    td_datetime.innerHTML = datel[0] + "年" + datel[1] + "月" + datel[2] + "日　" + dater[0] + ":" + dater[1]
    tr.appendChild(td_datetime)

    let td_name = document.createElement("td")
    td_name.innerHTML = reservation.guest_name + "様"
    tr.appendChild(td_name)

    let td_destination = document.createElement("td")
    td_destination.innerHTML = reservation.destination
    tr.appendChild(td_destination)

    let td_carnum = document.createElement("td")
    td_carnum.innerHTML = reservation.car_number
    tr.appendChild(td_carnum)

    let td_people = document.createElement("td")
    td_people.innerHTML = reservation.people_number
    tr.appendChild(td_people)

    let td_company = document.createElement("td")
    td_company.innerHTML = reservation.company
    tr.appendChild(td_company)

    table.appendChild(tr)
  })
}