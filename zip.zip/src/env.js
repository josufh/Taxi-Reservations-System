const firebaseConfig = {
  apiKey: "AIzaSyCQsPsP4CzjP6DwV5zcvABevMkujAj_w_w",
  authDomain: "kph-taxireservations.firebaseapp.com",
  projectId: "kph-taxireservations",
  storageBucket: "kph-taxireservations.appspot.com",
  messagingSenderId: "537156629961",
  appId: "1:537156629961:web:628832d15cac60af45a418",
  measurementId: "G-M7W2VF0HTM"
}

export { firebaseConfig }