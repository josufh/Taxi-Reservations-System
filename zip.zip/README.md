﻿# Taxi Reservations System

I made this system while working at Keio Plaza Hotel Shinjuku for managing taxi reservations for guests.

Using VSCode with webpack and Google Firebase.

Can do: (As of 24/07/22)
- Make a reservation, save it to database.
- Look what is in the database.

ToDo:
- Change reservations.
- Cancel reservations.
- Print reservations.
- Print day's reservations.
- Settings.